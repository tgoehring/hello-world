bzip2 plugin v1.6 for Total Commander

Automatic installation
==================
Double click on the plugin archive in Total Commander,
then follow the instructions

Manual installation
================
1. Unzip the bzip2dll.wcx to the Total Commander directory
2. In Total Commander, choose Configuration - Options
3. Open the 'Plugins' page
4. Click on "Configure" in the packer plugin section
5. type  bz2  as the extension
6. Click 'new type', and select the bzip2dll.wcx
7. Click OK

What it does:

  This plugin allows you to create and extract bzip2 archives.

Christian Ghisler
http://www.ghisler.com

History:
2014.09.24 Release v1.6
2014.09.24 Fixed: Memory leak in unpack function
2011.09.16 Added: Port to 64-bit completed
2010.07.07 Fixed: Constant beeps and no progress bar when using "test archives"
2010.01.27 Fixed: Configuration dialog: ESC not working, Copyright notice updated
2009.11.06 Added: Support for unpacking of multi-part BZip2 archives
2009.10.19 Added: Support for background operation (for upcoming TC 7.55)
2009.10.16 Added: Support for Unicode files
2008.04.07 Update v1.1 fixes various security issues
2001.12.19 initial release
